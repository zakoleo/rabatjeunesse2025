-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 18, 2025 at 12:04 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rabatjeunesse`
--

-- --------------------------------------------------------

--
-- Table structure for table `basketball_teams`
--

CREATE TABLE `basketball_teams` (
  `id` int(11) NOT NULL,
  `nom_equipe` varchar(255) NOT NULL,
  `categorie` varchar(10) NOT NULL,
  `genre` varchar(10) NOT NULL,
  `type_basketball` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL,
  `organisation` varchar(20) NOT NULL,
  `adresse` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beachvolley_teams`
--

CREATE TABLE `beachvolley_teams` (
  `id` int(11) NOT NULL,
  `nom_equipe` varchar(255) NOT NULL,
  `categorie` varchar(10) NOT NULL,
  `genre` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL,
  `organisation` varchar(20) NOT NULL,
  `adresse` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `football_categories`
--

CREATE TABLE `football_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age_range` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `football_categories`
--

INSERT INTO `football_categories` (`id`, `name`, `age_range`, `active`, `created`, `modified`) VALUES
(6, 'U12', 'Moins de 12 ans', 1, '2025-08-10 10:16:52', '2025-08-10 10:16:52'),
(7, 'U15', '12-15 ans', 1, '2025-08-10 10:16:52', '2025-08-10 10:16:52'),
(8, 'U18', '15-18 ans', 1, '2025-08-10 10:16:52', '2025-08-10 10:16:52'),
(9, '18+', '18 ans et plus', 1, '2025-08-10 10:16:52', '2025-08-10 10:16:52');

-- --------------------------------------------------------

--
-- Table structure for table `football_districts`
--

CREATE TABLE `football_districts` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `football_districts`
--

INSERT INTO `football_districts` (`id`, `name`, `active`, `created`, `modified`) VALUES
(1, 'Agdal', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28'),
(2, 'Hassan', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28'),
(3, 'Souissi', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28'),
(4, 'Yacoub El Mansour', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28'),
(6, 'Hay Riad', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28'),
(8, 'Hay Nahda', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28');

-- --------------------------------------------------------

--
-- Table structure for table `football_organisations`
--

CREATE TABLE `football_organisations` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `football_organisations`
--

INSERT INTO `football_organisations` (`id`, `name`, `active`, `created`, `modified`) VALUES
(4, 'Association sportive', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28'),
(5, 'Club', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28'),
(7, 'Groupe d\'amis', 1, '2025-08-10 08:44:28', '2025-08-10 08:44:28');

-- --------------------------------------------------------

--
-- Table structure for table `handball_teams`
--

CREATE TABLE `handball_teams` (
  `id` int(11) NOT NULL,
  `nom_equipe` varchar(255) NOT NULL,
  `categorie` varchar(10) NOT NULL,
  `genre` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL,
  `organisation` varchar(20) NOT NULL,
  `adresse` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `joueurs`
--

CREATE TABLE `joueurs` (
  `id` int(11) NOT NULL,
  `nom_complet` varchar(255) NOT NULL,
  `date_naissance` date NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `taille_vestimentaire` varchar(5) NOT NULL,
  `team_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `joueurs`
--

INSERT INTO `joueurs` (`id`, `nom_complet`, `date_naissance`, `identifiant`, `taille_vestimentaire`, `team_id`, `created`, `modified`) VALUES
(13, 'Irure sed ratione fa', '2011-12-18', 'Voluptatibus invento', 'XS', 3, '2025-08-13 09:29:26', '2025-08-13 09:29:26'),
(14, 'Eos quae ut nisi te', '1973-08-04', 'Neque molestias temp', 'XXL', 3, '2025-08-13 09:29:26', '2025-08-13 09:29:26'),
(15, 'Ex aliquid quasi ani', '2015-06-25', 'Qui laudantium fugi', 'L', 3, '2025-08-13 09:29:26', '2025-08-13 09:29:26'),
(16, 'Ab et pariatur Veli', '1978-05-23', 'Velit dolore porro l', 'XXL', 3, '2025-08-13 09:29:26', '2025-08-13 09:29:26'),
(17, 'Nulla consequatur V', '2023-07-28', '1213AD', 'XXL', 3, '2025-08-13 09:29:26', '2025-08-13 09:29:26'),
(18, 'Quibusdam ab accusam', '2014-08-31', 'Nihil sit itaque occ', 'XXL', 3, '2025-08-13 09:29:26', '2025-08-13 09:29:26'),
(19, 'Aperiam velit moles', '2019-11-03', 'Iusto irure dolore c', 'M', 4, '2025-08-13 09:33:46', '2025-08-13 09:33:46'),
(20, 'Cupidatat minus odio', '1979-11-28', 'Ab quas exercitation', 'XS', 4, '2025-08-13 09:33:46', '2025-08-13 09:33:46'),
(21, 'Minim irure id omnis', '2014-02-28', 'Qui impedit placeat', 'M', 4, '2025-08-13 09:33:46', '2025-08-13 09:33:46'),
(22, 'Facere dolorem non c', '1998-05-30', 'Dolor ab culpa quod ', 'XL', 4, '2025-08-13 09:33:46', '2025-08-13 09:33:46'),
(23, 'Eum cum at aliquid v', '2018-04-10', 'Velit odit deleniti ', 'S', 4, '2025-08-13 09:33:46', '2025-08-13 09:33:46'),
(24, 'Placeat omnis volup', '2003-04-19', 'Quae sint velit in r', 'XXL', 4, '2025-08-13 09:33:46', '2025-08-13 09:33:46'),
(25, 'Aliquip quas veniam', '2003-02-08', 'Architecto et facili', 'L', 4, '2025-08-13 09:33:46', '2025-08-13 09:33:46'),
(26, 'Facilis commodi reic', '2012-01-20', 'Lorem blanditiis sed', 'XS', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(27, 'Ut officia sequi vol', '2017-07-22', 'Aut porro ducimus n', 'XS', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(28, 'Est excepteur iste s', '1993-10-24', 'Aut dolor dolore com', 'XL', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(29, 'Nemo qui quam omnis ', '2003-02-25', 'Occaecat ea occaecat', 'XL', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(30, 'Consequatur id adi', '1978-03-27', 'Molestiae et quia ab', 'M', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(31, 'Ad mollit minima ill', '2020-02-21', 'Veritatis impedit q', 'XL', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(32, 'Delectus ut distinc', '1992-11-23', 'Nulla sint praesenti', 'S', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(33, 'Velit aliquip rerum', '2002-04-21', 'Voluptate quis venia', 'XXL', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(34, 'Consequuntur lorem v', '1987-08-08', 'Hic architecto dolor', 'XL', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(35, 'Sapiente excepteur m', '1980-11-07', 'Sed duis laborum vol', 'XXL', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54'),
(36, 'Non facere occaecat ', '1996-03-10', 'Et fugit quia a et ', 'S', 5, '2025-08-13 09:36:54', '2025-08-13 09:36:54');

-- --------------------------------------------------------

--
-- Table structure for table `phinxlog`
--

CREATE TABLE `phinxlog` (
  `version` bigint(20) NOT NULL,
  `migration_name` varchar(100) DEFAULT NULL,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `breakpoint` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `phinxlog`
--

INSERT INTO `phinxlog` (`version`, `migration_name`, `start_time`, `end_time`, `breakpoint`) VALUES
(20250809103904, 'CreateUsers', '2025-08-09 10:48:48', '2025-08-09 10:48:48', 0),
(20250809104529, 'CreateTeams', '2025-08-09 10:49:17', '2025-08-09 10:49:17', 0),
(20250809104541, 'CreateResponsables', '2025-08-09 10:49:17', '2025-08-09 10:49:17', 0),
(20250809104554, 'CreateEntraineurs', '2025-08-09 10:49:17', '2025-08-09 10:49:17', 0),
(20250809104618, 'CreateJoueurs', '2025-08-09 10:49:17', '2025-08-09 10:49:17', 0),
(20250809104640, 'CreateHandballTeams', '2025-08-09 10:49:17', '2025-08-09 10:49:17', 0),
(20250809104657, 'CreateBasketballTeams', '2025-08-09 10:49:17', '2025-08-09 10:49:17', 0),
(20250809104707, 'CreateVolleyballTeams', '2025-08-09 10:49:17', '2025-08-09 10:49:17', 0),
(20250809104720, 'CreateBeachvolleyTeams', '2025-08-09 10:49:17', '2025-08-09 10:49:17', 0),
(20250810082001, 'AddResponsableEntraineurFieldsToTeams', '2025-08-10 08:21:00', '2025-08-10 08:21:00', 0),
(20250810082010, 'DropResponsablesEntraineursTable', '2025-08-10 08:21:00', '2025-08-10 08:21:00', 0),
(20250810083808, 'CreateFootballCategories', '2025-08-10 08:39:35', '2025-08-10 08:39:35', 0),
(20250810083818, 'CreateFootballDistricts', '2025-08-10 08:39:35', '2025-08-10 08:39:35', 0),
(20250810083829, 'CreateFootballOrganisations', '2025-08-10 08:39:35', '2025-08-10 08:39:35', 0),
(20250810083907, 'UpdateTeamsForFootballReferences', '2025-08-10 08:39:35', '2025-08-10 08:39:35', 0),
(20250810084231, 'SeedFootballReferenceTables', '2025-08-10 08:44:28', '2025-08-10 08:44:28', 0),
(20250810101620, 'UpdateFootballCategories', '2025-08-10 10:16:52', '2025-08-10 10:16:52', 0),
(20250813123633, 'AddReferenceToTeams', '2025-08-13 12:36:58', '2025-08-13 12:36:58', 0),
(20250813125850, 'FixJoueursCascadeDelete', '2025-08-13 14:25:07', '2025-08-13 14:25:08', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL,
  `nom_equipe` varchar(255) NOT NULL,
  `categorie` varchar(10) NOT NULL,
  `football_category_id` int(11) DEFAULT NULL,
  `genre` varchar(10) NOT NULL,
  `type_football` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL,
  `football_district_id` int(11) DEFAULT NULL,
  `organisation` varchar(20) NOT NULL,
  `football_organisation_id` int(11) DEFAULT NULL,
  `adresse` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `responsable_nom_complet` varchar(255) NOT NULL,
  `responsable_date_naissance` date NOT NULL,
  `responsable_tel` varchar(20) NOT NULL,
  `responsable_whatsapp` varchar(20) NOT NULL,
  `responsable_cin_recto` varchar(255) NOT NULL,
  `responsable_cin_verso` varchar(255) NOT NULL,
  `entraineur_nom_complet` varchar(255) NOT NULL,
  `entraineur_date_naissance` date NOT NULL,
  `entraineur_tel` varchar(20) NOT NULL,
  `entraineur_whatsapp` varchar(20) NOT NULL,
  `entraineur_cin_recto` varchar(255) NOT NULL,
  `entraineur_cin_verso` varchar(255) NOT NULL,
  `entraineur_same_as_responsable` tinyint(1) NOT NULL,
  `reference_inscription` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `nom_equipe`, `categorie`, `football_category_id`, `genre`, `type_football`, `district`, `football_district_id`, `organisation`, `football_organisation_id`, `adresse`, `user_id`, `created`, `modified`, `responsable_nom_complet`, `responsable_date_naissance`, `responsable_tel`, `responsable_whatsapp`, `responsable_cin_recto`, `responsable_cin_verso`, `entraineur_nom_complet`, `entraineur_date_naissance`, `entraineur_tel`, `entraineur_whatsapp`, `entraineur_cin_recto`, `entraineur_cin_verso`, `entraineur_same_as_responsable`, `reference_inscription`) VALUES
(3, 'Et quibusdam sit sapiente et pariatur2', 'U15', NULL, 'Homme', '6x6', 'Hassan', NULL, 'Association sportive', NULL, 'Placeat quasi corru', 2, '2025-08-13 09:29:26', '2025-08-13 09:30:02', 'Mohamed Ali', '1976-12-15', '0661136677', '0661136677', 'uploads/teams/1755077366_responsable_recto_Screenshot 2025-08-09 at 12.17.45.png', 'uploads/teams/1755077366_responsable_verso_Screenshot 2025-08-09 at 12.17.45.png', 'Mohamed Ali', '1976-12-15', '0661136677', '0661136677', 'uploads/teams/1755077366_responsable_recto_Screenshot 2025-08-09 at 12.17.45.png', 'uploads/teams/1755077366_responsable_verso_Screenshot 2025-08-09 at 12.17.45.png', 1, NULL),
(4, 'Iste rerum voluptate qui ', 'U15', NULL, 'Femme', '6x6', 'Hay Nahda', NULL, 'Groupe d\'amis', NULL, 'Voluptas dignissimos', 1, '2025-08-13 09:33:46', '2025-08-13 09:33:46', 'lorem ipsum', '1980-10-12', '0661136677', '0661136677', 'uploads/teams/1755077626_responsable_recto_Screenshot 2025-08-09 at 12.17.45.png', 'uploads/teams/1755077626_responsable_verso_Screenshot 2025-08-09 at 12.17.45.png', 'Tarik', '1994-08-01', '0661136678', '0661136676', 'uploads/teams/1755077626_entraineur_recto_Screenshot 2025-08-09 at 12.17.45.png', 'uploads/teams/1755077626_entraineur_verso_Screenshot 2025-08-09 at 12.17.45.png', 0, NULL),
(5, 'Veniam dolore nemo est voluptatem ipsum ut provident obcaecati', '18+', NULL, 'Femme', '11x11', 'Hay Riad', NULL, 'Association sportive', NULL, 'Molestiae molestias ', 1, '2025-08-13 09:36:54', '2025-08-13 09:36:54', 'Voluptatibus voluptatem magna molestias et aute ratione quod voluptas et velit delectus voluptate et tempora non ex', '2005-04-04', '0661137788', '0661137788', 'uploads/teams/1755077814_responsable_recto_Screenshot 2025-08-09 at 12.17.45.png', 'uploads/teams/1755077814_responsable_verso_Screenshot 2025-08-09 at 12.17.45.png', 'Incidunt odit id optio aliquid et nesciunt culpa libero delectus saepe recusandae Nostrum excepturi voluptatem elit ea autem et odit', '2010-03-07', '0661137788', '0661137788', 'uploads/teams/1755077814_entraineur_recto_Screenshot 2025-08-09 at 12.17.45.png', 'uploads/teams/1755077814_entraineur_verso_Screenshot 2025-08-09 at 12.17.45.png', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created`, `modified`) VALUES
(1, 'zak@lifemoz.com', 'zak@lifemoz.com', '$2y$10$XbjHVCCt8X53IinkjwL7zu0duC3..gHtobI6fVZk2.PPoBLc6ttA2', '2025-08-09 11:01:47', '2025-08-09 11:01:47'),
(2, 'imane', 'imane@lifemoz.com', '$2y$10$/Be.ZLu5Ha0ovtt0AdW33OQi34mLVxgo2dNgN2tlLuaTgBsbB8N9m', '2025-08-13 09:24:28', '2025-08-13 09:24:28');

-- --------------------------------------------------------

--
-- Table structure for table `volleyball_teams`
--

CREATE TABLE `volleyball_teams` (
  `id` int(11) NOT NULL,
  `nom_equipe` varchar(255) NOT NULL,
  `categorie` varchar(10) NOT NULL,
  `genre` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL,
  `organisation` varchar(20) NOT NULL,
  `adresse` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `basketball_teams`
--
ALTER TABLE `basketball_teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beachvolley_teams`
--
ALTER TABLE `beachvolley_teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `football_categories`
--
ALTER TABLE `football_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `football_districts`
--
ALTER TABLE `football_districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `football_organisations`
--
ALTER TABLE `football_organisations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `handball_teams`
--
ALTER TABLE `handball_teams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `joueurs`
--
ALTER TABLE `joueurs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_id` (`team_id`);

--
-- Indexes for table `phinxlog`
--
ALTER TABLE `phinxlog`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference_inscription` (`reference_inscription`),
  ADD KEY `football_category_id` (`football_category_id`),
  ADD KEY `football_district_id` (`football_district_id`),
  ADD KEY `football_organisation_id` (`football_organisation_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `volleyball_teams`
--
ALTER TABLE `volleyball_teams`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `basketball_teams`
--
ALTER TABLE `basketball_teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `beachvolley_teams`
--
ALTER TABLE `beachvolley_teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `football_categories`
--
ALTER TABLE `football_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `football_districts`
--
ALTER TABLE `football_districts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `football_organisations`
--
ALTER TABLE `football_organisations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `handball_teams`
--
ALTER TABLE `handball_teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `joueurs`
--
ALTER TABLE `joueurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `volleyball_teams`
--
ALTER TABLE `volleyball_teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `joueurs`
--
ALTER TABLE `joueurs`
  ADD CONSTRAINT `joueurs_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`football_category_id`) REFERENCES `football_categories` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `teams_ibfk_2` FOREIGN KEY (`football_district_id`) REFERENCES `football_districts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `teams_ibfk_3` FOREIGN KEY (`football_organisation_id`) REFERENCES `football_organisations` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
